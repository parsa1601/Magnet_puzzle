public class Player {

    public void play(){
        Board board = new Board();
        board.boardCreator();
    }
}
